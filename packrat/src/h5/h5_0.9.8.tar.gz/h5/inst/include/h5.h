#include "H5Cpp.h"
#include "Rcpp.h"

#ifndef __h5_h__
#define __h5_h__
using namespace H5;
using namespace Rcpp;
using namespace std;
#endif // __h5_h__


